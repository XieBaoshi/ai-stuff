from dynamicprompts.generators import RandomPromptGenerator
from dynamicprompts.wildcards.wildcard_manager import WildcardManager

def generate_prompts():
    txt_dir_path = r"D:\Documents\wildcards"
    wildcard_manager = WildcardManager(txt_dir_path)
    generator = RandomPromptGenerator(wildcard_manager=wildcard_manager)
    promptline = "__prompt__"
    prompts = generator.generate(promptline, num_prompts=1)
    return prompts[0]

output_file_path = "output.txt"

# Clear the content of the output file
with open(output_file_path, "w") as file:
    file.write("")

# Generate and write prompts 999 times
for _ in range(20):
    with open(output_file_path, "a") as file:
        file.write(generate_prompts() + "\n")